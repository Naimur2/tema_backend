-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 16, 2023 at 11:24 AM
-- Server version: 5.7.42
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `temafusiondev_groganbaer_mobile_backend`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `starting_date` datetime NOT NULL,
  `ending_date` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `team_id`, `starting_date`, `ending_date`, `created_at`, `updated_at`) VALUES
(1, 'Green Team Breakout #1', 1, '2023-07-11 10:08:00', '2023-07-11 00:08:00', '2023-07-05 19:08:59', '2023-07-05 20:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `file`, `folder_id`, `created_at`, `updated_at`) VALUES
(1, 'FusionDev_logo.png', 'files/37KUChfqpz83VtRfSzZO5d9droBqd8a6nzuH6nT6.png', 1, '2023-07-05 19:09:29', '2023-07-05 19:09:29');

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `name`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'Event Pictures1', NULL, '2023-07-05 19:09:16', '2023-07-05 19:09:16'),
(2, 'Day2', 1, '2023-07-05 20:14:21', '2023-07-05 20:14:21'),
(3, 'Event2', NULL, '2023-07-13 19:15:20', '2023-07-13 19:15:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2013_05_24_111548_create_teams_table', 1),
(2, '2014_10_12_000000_create_users_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_05_25_111956_create_events_table', 1),
(7, '2023_06_12_204622_create_folders_table', 1),
(8, '2023_06_12_204703_create_files_table', 1),
(9, '2023_07_01_073439_add_fcm_token_column_to_users_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 5, 'MyApp', '6041cd4a8b7dd7eeed0da0264887844aa7f7026d5a346b15a8496513e0053560', '[\"*\"]', NULL, '2023-07-12 23:41:59', '2023-07-12 23:41:59'),
(2, 'App\\Models\\User', 6, 'MyApp', 'ba46150471eb1cf6e472d72af9b78358ee90157727c40345f138838a33920a11', '[\"*\"]', NULL, '2023-07-12 23:49:42', '2023-07-12 23:49:42'),
(3, 'App\\Models\\User', 7, 'MyApp', '0605d6f65b8f0c4b14b8ee6c81a0aaecba5c97ac26ee3551cee63d3695b7d364', '[\"*\"]', NULL, '2023-07-13 00:03:37', '2023-07-13 00:03:37'),
(4, 'App\\Models\\User', 8, 'MyApp', '0aed9a8326ee51f7eeb5a724c53eddc67eff70873f18911e8ad8f4b253de3939', '[\"*\"]', NULL, '2023-07-13 16:25:16', '2023-07-13 16:25:16'),
(5, 'App\\Models\\User', 9, 'MyApp', '51622ff16d378dd0d36b70a74bf0a854d756b985142e85cf79729d05b0b3675c', '[\"*\"]', NULL, '2023-07-13 17:04:26', '2023-07-13 17:04:26'),
(6, 'App\\Models\\User', 10, 'MyApp', '40d32799be729aac0e9504676de76572410c602e150cb5546e524e81cd3a7d5e', '[\"*\"]', NULL, '2023-07-13 17:26:05', '2023-07-13 17:26:05'),
(7, 'App\\Models\\User', 11, 'MyApp', 'a13834bbb7ac5bd166613710d6b204f3871322379831a6970ad95d4e5647e9de', '[\"*\"]', NULL, '2023-07-13 17:44:45', '2023-07-13 17:44:45'),
(8, 'App\\Models\\User', 6, 'MyApp', '54cf933674a99bfcabaeb4fb5fc7bd068da270398711cd2b80c79113a264fa9b', '[\"*\"]', NULL, '2023-07-13 17:45:47', '2023-07-13 17:45:47'),
(9, 'App\\Models\\User', 10, 'MyApp', '44f9131ff60e1693a181fe05ab5e0e421e93531c408c61a33b812138193cc230', '[\"*\"]', '2023-07-14 00:27:59', '2023-07-13 17:59:20', '2023-07-14 00:27:59'),
(10, 'App\\Models\\User', 12, 'MyApp', '3d6ee9fac0e454dc7cdea6ba72902b17fc011b38b1d85689063f7d3c56c38512', '[\"*\"]', NULL, '2023-07-16 11:35:19', '2023-07-16 11:35:19'),
(13, 'App\\Models\\User', 5, 'MyApp', 'aa03c9367da940cc39bbb6845c67444ab16d697104ee100d786575cefe60f031', '[\"*\"]', '2023-07-16 12:18:54', '2023-07-16 12:18:11', '2023-07-16 12:18:54'),
(14, 'App\\Models\\User', 14, 'MyApp', '8c8ded7c3348dd4b69333de8d654e9dad045052c3b541f7df55d9ab4a0484f33', '[\"*\"]', '2023-07-16 13:45:02', '2023-07-16 13:42:24', '2023-07-16 13:45:02');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `color`, `score`, `created_at`, `updated_at`) VALUES
(1, 'Red Team', '#ff0000', 476521240, '2023-07-05 08:29:54', '2023-07-05 19:07:25'),
(2, 'Green Team', '#00ff04', 18, '2023-07-05 08:29:54', '2023-07-05 19:07:45'),
(3, 'Purple Team', '#d100d1', 9308, '2023-07-05 08:29:54', '2023-07-05 19:08:03'),
(4, 'Blue Team', '#2b00ff', 7188984, '2023-07-05 08:29:54', '2023-07-05 19:08:17'),
(5, 'Yellow Team', '#eff019', 2931391, '2023-07-05 08:29:54', '2023-07-05 19:08:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shirt_size` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arrival_date` date NOT NULL,
  `departure_date` date NOT NULL,
  `bed_preference` int(11) NOT NULL,
  `team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userType` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcm_token` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `mobile_number`, `shirt_size`, `image_path`, `company_name`, `arrival_date`, `departure_date`, `bed_preference`, `team_id`, `email_verified_at`, `password`, `userType`, `is_active`, `remember_token`, `fcm_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '', 'admin', 'admin@admin.com', '', '9', 'images/undraw_profile.svg', 'Gigaheap', '2023-04-20', '2023-05-20', 0, 1, NULL, '$2y$10$zw/bWYWO4XCb4Ygf4AtY7ui2TWQ5e3mDJHkbqy0KntHQYpscGdoVG', 0, 1, 'WBUQDIYajfeIsk1sSzzuM72PE3eE5OPNLDAU2P3hNKCoHybwhzG6g6VP8ADZ', NULL, NULL, NULL),
(2, 'Umar', 'Barlas', 'umarbarlas', 'umarbarlas4@gmail.com', '923204343549', 'M', 'images/undraw_profile.svg', 'Gigaheap', '2023-04-20', '2023-05-20', 0, 1, NULL, '$2y$10$6XVaPt4NmHjOu2m0aAoJouzjU/blKkSWeFfZFGvw2nJIzyAZcI7rm', 1, 1, NULL, NULL, NULL, '2023-07-05 22:40:53'),
(3, 'Aleem', 'Ahmad', 'aleemahmad', 'aleemahmada107@gmail.com', '923034410038', 'XL', 'images/undraw_profile.svg', 'Gigaheap', '2023-04-20', '2023-05-20', 1, 3, NULL, '$2y$10$RXAnsW.rL8P5KabkRDKRgOWZSvRE.CjdpANwqKlUkEsaIQo8ovKiW', 1, 1, NULL, NULL, NULL, '2023-07-05 22:41:01'),
(4, 'Michael', 'Baer', 'fusioncorp', 'michael@fusioncorpdesign.com', '5025008678', '2XL', 'images/undraw_profile.svg', 'Fusioncorp', '2023-07-12', '2023-07-19', 1, 5, NULL, '$2y$10$t4mh0/WiJA1WLHxBIgeTTO38fwjhMu6K/IexNJZpiKj61tiFwWw82', 1, 1, NULL, NULL, '2023-07-05 23:05:02', '2023-07-05 22:41:08'),
(5, 'Shimion', 'Bala', 'Shimion', 'shimion@fusioncorpdesign.com', '8801717614480', 'M', 'images/i48uhb9IrQfwujCBjfadqYQULmW417KCahmphV6c.png', 'Fusion', '2023-12-12', '2023-02-02', 1, 2, NULL, '$2y$10$1TcvbJnge1QhmB/kE/TXOenVmG6E9kFqjC4y/kugjmeMgI1XxVZd2', 1, 1, NULL, NULL, '2023-07-12 23:41:59', '2023-07-14 01:09:17'),
(6, 'First', 'Last', 'iqueusernamea', 'aleemahmad@gmail.com', '45678121322', 'M', 'images/HP8zZdMhcLOnq1NJRFOzMTp2GaEWsqEFFXUWyQgq.png', 'C-Name', '2023-06-03', '2023-06-06', 1, NULL, NULL, '$2y$10$C7GkZF/l2tcutiLHFYXIbujDLiLiMHcyJLMCkxccXGNsW63NaCj7C', 1, 1, NULL, NULL, '2023-07-12 23:49:42', '2023-07-12 23:49:42'),
(7, 'Naimur', 'Rahaman', 'Hello', 'ekjono2@gmail.com', '5551234567', 'M', 'images/FyRnqpAmbZKb72pBm9sTUEKkx0H2wlGAOIgV1fCE.jpg', 'Comt', '2023-04-06', '2023-08-08', 1, NULL, NULL, '$2y$10$rq1HnhdUx.ZmI4V5X./LIOT1KuXAG.FEJvnOyxL0KUjydkBee01f.', 1, 1, NULL, NULL, '2023-07-13 00:03:37', '2023-07-13 00:03:37'),
(8, 'Naimur', 'Rah', 'Yyyyyy', 'ekjono356@gmail.com', '3551234567', 'M', 'images/Sp2KIRnhDX4NDPyLw1FVlGlW3tjTjfI9WbIsLROE.jpg', 'wesd', '2022-04-23', '2022-05-23', 1, NULL, NULL, '$2y$10$6al/I8NfaYeBM.PWA9ajs.jDA6AFbnzIJEssOLXiFFowlOOlwTxgu', 1, 1, NULL, NULL, '2023-07-13 16:25:16', '2023-07-13 16:25:16'),
(9, 'Naimur', 'Rah', 'Yyyyyy33', 'ekjono365@gmail.com', '3551234569', 'M', 'images/T4XwbzYF3jtiF2OLmXXZQeUF5PNfVpMwHWCs07Jj.jpg', 'wesd', '2022-04-23', '2022-05-23', 1, NULL, NULL, '$2y$10$B1ZOS3BpA4NFCbCXV8RBr.cagRiYuPQ4BfqWKnRTVN9tO7n/YQDRK', 1, 1, NULL, NULL, '2023-07-13 17:04:26', '2023-07-13 17:04:26'),
(10, 'Juu', 'Byer', 'nightly', 'bby@gmail.com', '2229221982', 'M', 'images/R2Dc7O8fxppM0M2LEfcJ64kUArErzQRFy5hYeOaE.jpg', 'DC', '2002-05-22', '2022-06-22', 1, NULL, NULL, '$2y$10$iARKuw50l36zFvJ5GnpuXeiNb8z2wVeoRVWOvkEYZgcqaumC/1d5i', 1, 1, NULL, NULL, '2023-07-13 17:26:05', '2023-07-13 17:26:05'),
(11, 'rtgre', 'Lastreretrtre', 'iqueuser', 'alee@gmail.com', '45678121', 'M', 'images/etsJbrT7A2aptgDCod0AaKIh5Vxupb2NrqN02HzL.png', 'C-Name', '2023-06-03', '2023-06-06', 1, NULL, NULL, '$2y$10$nYAUjlrEC8dfGp8NDYc9Nuveyn6EqF8k0RUHdLsHJRDK2G74GQtAO', 1, 1, NULL, NULL, '2023-07-13 17:44:45', '2023-07-13 17:44:45'),
(12, 'dsfd', 'dsfds', 'Ndf', 'abc@dfg.com', '24785231982', 'M', 'images/AwMh6GMjAg0MFBEyeKDjsXdKwP9dHkJcU6IbwQTt.jpg', 'dsfdsd', '2024-06-16', '2025-06-16', 1, NULL, NULL, '$2y$10$veFdEmr6s0OQF6AHCqSE0O65FFV8JuhlPZzlEtBgjmal7cgoWXo2i', 1, 1, NULL, NULL, '2023-07-16 11:35:18', '2023-07-16 11:35:18'),
(13, 'dsfd', 'dsfds', 'Ndf123', 'abc@bbg.com', '247888888', 'M', 'images/j60NtbE8bzx7WNlwiu2NlGYhTbbUcIz51wD0eTsd.jpg', 'dsfdsd', '2024-06-16', '2025-06-16', 1, NULL, NULL, '$2y$10$NjM9sZcqYE5pmxvCahrIVeIHjCfs6aQap5FKoU5MMRGMhKdaBaAnG', 1, 1, NULL, NULL, '2023-07-16 11:37:59', '2023-07-16 11:37:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `events_name_unique` (`name`),
  ADD KEY `events_team_id_foreign` (`team_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `files_folder_id_foreign` (`folder_id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teams_name_unique` (`name`),
  ADD UNIQUE KEY `teams_color_unique` (`color`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_team_id_foreign` (`team_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_folder_id_foreign` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
